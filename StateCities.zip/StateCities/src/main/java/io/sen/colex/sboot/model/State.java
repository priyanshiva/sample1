package io.sen.colex.sboot.model;


public class State {
	
	private String code;
	private String name;
	
	public String getCode() {
		return code;
	}
	
	public State() {
		super();
		// TODO Auto-generated constructor stub
	}

	public State(String code, String name) {
		super();
		this.code = code;
		this.name = name;
	}

	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public int hashCode() {
		return code.hashCode();
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		State other = (State) obj;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		return true;
	}
	
    @Override
    public String toString() {
        return String.format(
                "State [code=%s, name=%s]", code, name);
    }
}
