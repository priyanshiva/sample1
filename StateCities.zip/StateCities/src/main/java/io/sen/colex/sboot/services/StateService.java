package io.sen.colex.sboot.services;

import io.sen.colex.sboot.model.State;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class StateService {
	
    private static List<State> states = new ArrayList<State>();
    
    static {
        states.add(new State("TN", "TamilNadu"));
        states.add(new State("KN", "KonguNadu"));
        states.add(new State("KL", "Kerela"));
    }
    
    public List<State> listStates() {
        return states;
    }
    
    public State retrieveState(String code) {
        for (State state : states) {
        	System.out.println(state);
            if (state.getCode().equals(code)) {
                return state;
            }
        }
        return null;
    }

    public void updateState(State state){
    		states.remove(state);
    		states.add(state);
    }

    public void addState(String code, String name) {
        states.add(new State(code, name));
    }

    public void deleteState(String code) {
        Iterator<State> iterator = states.iterator();
        while (iterator.hasNext()) {
            State state = iterator.next();
            if (state.getCode().equals(code)) {
                iterator.remove();
            }
        }
    }
}
