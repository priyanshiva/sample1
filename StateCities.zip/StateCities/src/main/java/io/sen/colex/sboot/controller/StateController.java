package io.sen.colex.sboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import io.sen.colex.sboot.model.State;
import io.sen.colex.sboot.services.StateService;

@RestController
@RequestMapping("/state")

public class StateController {

	@Autowired
	private StateService stateService;

	@RequestMapping(value = "/list", method = RequestMethod.GET, produces = "application/json")
	public Iterable<State> list(Model model) {
		Iterable<State> productList = stateService.listStates();
		return productList;
	}

	@RequestMapping(value = "/show/{code}", method = RequestMethod.GET, produces = "application/json")
	public State showState(@PathVariable String code, Model model) {
		State state = stateService.retrieveState(code);
		return state;
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity saveState(@RequestBody State state) {
		stateService.addState(state.getCode(), state.getName());
		return new ResponseEntity("State added successfully", HttpStatus.OK);
	}

	@RequestMapping(value = "/update/{code}", method = RequestMethod.PUT, produces = "application/json")
	public ResponseEntity updateState(@PathVariable String code, @RequestBody State state) {
		// State storedState = stateService.retrieveState(code);
		// storedState.setName(state.getName());
		stateService.updateState(state);
		return new ResponseEntity("State updated successfully", HttpStatus.OK);
	}

	@RequestMapping(value = "/delete/{code}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity delete(@PathVariable String code) {
		stateService.deleteState(code);
		return new ResponseEntity("State deleted successfully", HttpStatus.OK);
	}

}
