package io.sen.colex.sboot.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"io.sen.colex.sboot"})
public class StateCitiesApplication {

	public static void main(String[] args) {
		SpringApplication.run(StateCitiesApplication.class, args);
	}
}
